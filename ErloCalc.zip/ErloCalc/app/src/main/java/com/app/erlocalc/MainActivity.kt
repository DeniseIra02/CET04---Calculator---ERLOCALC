package com.app.erlocalc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.TextView
import javax.script.ScriptEngine
import javax.script.ScriptEngineManager

class MainActivity : AppCompatActivity() {
    private lateinit var input: TextView
    private lateinit var result: TextView
    private lateinit var all_clr: Button
    private lateinit var clear: Button
    private lateinit var percent: Button
    private lateinit var divide: Button
    private lateinit var multiply: Button
    private lateinit var subtract: Button
    private lateinit var add: Button
    private lateinit var equal: Button
    private lateinit var point: Button
    private lateinit var doublezero: Button
    private lateinit var zero: Button
    private lateinit var num_one: Button
    private lateinit var num_two: Button
    private lateinit var num_three: Button
    private lateinit var num_four: Button
    private lateinit var num_five: Button
    private lateinit var num_six: Button
    private lateinit var num_seven: Button
    private lateinit var num_eight: Button
    private lateinit var num_nine: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        result = findViewById(R.id.result)
        all_clr = findViewById(R.id.all_clr)
        clear = findViewById(R.id.clear)
        percent = findViewById(R.id.percent)
        divide = findViewById(R.id.divide)
        multiply = findViewById(R.id.multiply)
        subtract = findViewById(R.id.subtract)
        add = findViewById(R.id.add)
        equal = findViewById(R.id.equal)
        point = findViewById(R.id.point)
        doublezero = findViewById(R.id.doublezero)
        zero = findViewById(R.id.zero)
        num_one = findViewById(R.id.num_one)
        num_two = findViewById(R.id.num_two)
        num_three = findViewById(R.id.num_three)
        num_four = findViewById(R.id.num_four)
        num_five = findViewById(R.id.num_five)
        num_six = findViewById(R.id.num_six)
        num_seven = findViewById(R.id.num_seven)
        num_eight = findViewById(R.id.num_eight)
        num_nine = findViewById(R.id.num_nine)

        input.movementMethod = ScrollingMovementMethod()
        input.isActivated = true
        input.isPressed = true

        var str:String

        all_clr.setOnClickListener{
            inputText("0")
            input.textSize = 65F
            result.textSize = 35F
            resultText()
        }

        clear.setOnClickListener{
            if (input.text.toString().isNotEmpty()){
                val lastnum = input.text.toString().lastIndex
                str = input.text.toString().substring(0,lastnum)
                inputText(str)
                resultText()
            }
        }

        percent.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "%"
                inputText(str)
            }
        }

        divide.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "/"
                inputText(str)
            }
        }

        multiply.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "*"
                inputText(str)
            }
        }

        subtract.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "-"
                inputText(str)
            }
        }

        add.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "+"
                inputText(str)
            }
        }

        equal.setOnClickListener{
            input.textSize = 35F
            result.textSize = 65F
        }

        point.setOnClickListener{
            if(input.text.toString().endsWith("%")||input.text.toString().endsWith("/")||input.text.toString().endsWith("*")||input.text.toString().endsWith("-")||input.text.toString().endsWith("+")||input.text.toString().endsWith(".")){
                str = input.text.toString()
                inputText(str)
            }else{
                str = input.text.toString() + "."
                inputText(str)
            }
        }

        doublezero.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "00"
                inputText(str)
                resultText()
            }else{
                str = input.text.toString() + "00"
                inputText(str)
                resultText()
            }
        }

        zero.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "0"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "0"
                inputText(str)
                resultText()
            }
        }

        num_one.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "1"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "1"
                inputText(str)
                resultText()
            }
        }

        num_two.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "2"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "2"
                inputText(str)
                resultText()
            }
        }

        num_three.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "3"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "3"
                inputText(str)
                resultText()
            }
        }

        num_four.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "4"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "4"
                inputText(str)
                resultText()
            }
        }

        num_five.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "5"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "5"
                inputText(str)
                resultText()
            }
        }

        num_six.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "6"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "6"
                inputText(str)
                resultText()
            }
        }

        num_seven.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "7"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "7"
                inputText(str)
                resultText()
            }
        }

        num_eight.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "8"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "8"
                inputText(str)
                resultText()
            }
        }

        num_nine.setOnClickListener{
            if(input.text.toString().startsWith("0")){
                str = input.text.toString().replace("0","") + "9"
                inputText(str)
                resultText()
            }else {
                str = input.text.toString() + "9"
                inputText(str)
                resultText()
            }
        }
    }
    private fun inputText(str:String){
        input.text =str
    }

    private fun resultText(){
        val inp = input.text.toString()
        val engine:ScriptEngine = ScriptEngineManager().getEngineByName("rhino")
        try {
            val res = engine.eval(inp)
            if (res.toString().endsWith(".0")){
                result.text = "=" + res.toString().replace(".0","")
            }else{
                result.text = "=$res"
            }
        }catch (e:Exception){
            input.text = input.text.toString()
            result.text = input.text.toString()
        }
    }
}